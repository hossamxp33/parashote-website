var i, j, k, m,
    equipList = document.getElementById("chooseEquip_list"),
    equipLink = document.getElementsByClassName("equip"),
    kindSelect = document.getElementById("select-kind"),
    areaSelect = document.getElementById("select-area"),
    dealSelect = document.getElementById("select-deal");
$(document).ready(function () {
    var currentId;
    var currentLocation;
    $(".more").hide();
    $('#complete').hide();
    //machine
    $.ajax({
        url: "http://naql.codesroots.com/api/machines.json",
        type: "GET",
        accept: "application/json",
        success: function (result) {
            $.each(result, function (i, value) {
                for (var i in value) {
                    equipList.innerHTML +=
                        "<div class='col-md-4 col-sm-6 equip'  id='" + value[i].id + "' location='" + value[i].location + "' nme=" + value[i].name + " >\
                            <div class='icon'>\
                                <img src=' http://naql.codesroots.com/library/machine/" + value[i].photo + "' alt='' class='img-responsive center-block'>\
                            </div>\
                            <div class='title text-center'>\
                                <h3>" + value[i].name + "</h3>\
                            </div>\
                        </div>";
                }
            });
            $('.equip').on('click', function () {
                currentId = this.id;
                currentLocation = $(this).attr("location");
                currentName = $(this).attr("name");

                $(".more").show();
                $(this).attr("class", "col-md-4 col-sm-6 equip clicked");
                //machine details
                $.ajax({
                    url: "http://naql.codesroots.com/api/machineDetails/subCat/" + currentId + ".json",
                    type: "GET",
                    accept: "application/json",
                    success: function (result) {
                        $.each(result, function (j, equip) {
                            for (var j in equip) {
                                kindSelect.innerHTML +=
                                    "<option value=" + equip[j].name + " detail-id=" + equip[j].id + ">" + equip[j].name + "</option>";
                            }
                        })
                        if (currentLocation === "2") {
                            $("#end-location").show();
                        } else {
                            $("#end-location").hide();
                        }
                    }
                });
                //Reservation Type
                $.ajax({
                    url: "http://naql.codesroots.com/api/ReservationTypes.json",
                    type: "GET",
                    accept: "application/json",
                    success: function (data) {
                        $.each(data, function (k, reservation) {
                            for (m in reservation) {
                                dealSelect.innerHTML +=
                                    "<option value=" + reservation[m].name + " id=" + reservation[m].id + ">" + reservation[m].name + "</option>";
                            }
                        })
                    }
                });
                var jsonData;
                //Send Data 
                $("#complete").hide();
                $('#confirm').on('click', function (e) {
                    //e.preventDefault();
                    if (currentLocation === "1") {
                        jsonData = JSON.stringify({
                            "user_id": 1,
                            "start_point": $("#select-start-area").val(),
                            "end_point": $("#select-end-area").val(),
                            "date": $("#datepicker1").val(),
                            "owner_id": 94,
                            "machine_id": $(this).attr("id"),
                            "machine_name": $(this).attr("name"),
                            "machine_detail_id": $(this).attr("detail-id"),
                            "reservation_type": $('#select-deal').text(),
                            "reservation_type_id": $(this).attr("id"),
                            "start_lat": $("#us1-lat").text(),
                            "start_long": $("#us1-lon").text(),
                            "end_lat": 0,
                            "end_long": 0,
                            "description": $("#description").val()
                        });
                    } else {
                        jsonData = JSON.stringify({
                            "user_id": 1,
                            "start_point": $("#select-start-area").val(),
                            "end_point": $("#select-start-area").val(),
                            "date": $("#datepicker1").val(),
                            "owner_id": 94,
                            "machine_id": $(this).attr("id"),
                            "machine_name": $(this).attr("name"),
                            "machine_detail_id": $(this).attr("detail-id"),
                            "reservation_type": $('#select-deal').text(),
                            "reservation_type_id": $(this).attr("id"),
                            "start_lat": $("#us1-lat").text(),
                            "start_long": $("#us1-lon").text(),
                            "end_lat": $("#us2-lat").text(),
                            "end_long": $("#us2-lon").text(),
                            "description": $("#dscription").val()
                        });
                    }
                    $.ajax({
                        url: "http://naql.codesroots.com/api/reservations/add.json",
                        type: "POST",
                        data: jsonData,
                        contentType: "application/json",
                        beforeSend: function(){
                            $('.msg').html("<img scr='../img/icon/Loading_icon.gif'>");
                        } ,
                        success: function (data) {
                                $("#order").fadeOut(800);
                                $('#complete').fadeIn(800);
                        }
                    })
                })
            });
            $.ajax({
                url: "http://naql.codesroots.com/api/areas.json",
                type: "GET",
                accept: "application/json",
                success: function (data) {
                    $.each(data, function (k, area) {
                        for (k in area) {
                            areaSelect.innerHTML +=
                                "<option value=" + area[k].name + ">" + area[k].name + "</option>";
                        }
                    })
                }
            });
        }
    });

    $("#order").hide();
    $(".more").click(function () {
        $("#order").fadeIn(1000);
        $("#chooseEquip_list").fadeOut(800);
        $(this).hide();
    });
});